package com.sahani2020.suCheckerRoot;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.TranslateAnimation;
import android.widget.ImageView;
import android.widget.Toast;

import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.AdSize;
import com.facebook.ads.AdView;
import com.facebook.ads.AudienceNetworkAds;
import com.facebook.ads.InterstitialAd;
import com.facebook.ads.InterstitialAdListener;

public class MainActivity extends AppCompatActivity {

    TranslateAnimation animate; //animation
    ImageView red, green;       //ImageView
    private Animation bounce;
    ImageView b1;
    TextView text,text2, rootStatus;        //TextView

    LinearLayout adContainer,adContainer2;
    public InterstitialAd interstitialAd;
    public AdView adView,adView2;
    public final String TAG = MainActivity.class.getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        AudienceNetworkAds.initialize(this);
        setContentView(R.layout.activity_main);

        // Find the Ad Container
         adContainer = (LinearLayout) findViewById(R.id.banner_container);
        // Find the Ad Container
         adContainer2 = (LinearLayout) findViewById(R.id.banner_container2);
        //=========================================
        DisplayAds2();
        showAlertDialog();
        //=========================================
        adView2 = new AdView(this, "3295246890507214_3295253347173235", AdSize.BANNER_HEIGHT_50);
        // Add the ad view to your activity layout
        adContainer2.addView(adView2);
        // Request an ad
//        adView2.loadAd();
        //==========================================
        interstitialAd = new InterstitialAd(this, "3295246890507214_3295254213839815");
        interstitialAd.setAdListener(new InterstitialAdListener() {
            @Override
            public void onInterstitialDisplayed(Ad ad) {
                // Interstitial ad displayed callback
                Log.e(TAG, "Interstitial ad displayed.");
            }

            @Override
            public void onInterstitialDismissed(Ad ad) {
                // Interstitial dismissed callback
                Log.e(TAG, "Interstitial ad dismissed.");
                adView2.loadAd();
            }

            @Override
            public void onError(Ad ad, AdError adError) {
                // Ad error callback
                Log.e(TAG, "Interstitial ad failed to load: " + adError.getErrorMessage());
            }

            @Override
            public void onAdLoaded(Ad ad) {
                // Interstitial ad is loaded and ready to be displayed
                Log.d(TAG, "Interstitial ad is loaded and ready to be displayed!");
                // Show the ad
                interstitialAd.show();
            }

            @Override
            public void onAdClicked(Ad ad) {
                // Ad clicked callback
                Log.d(TAG, "Interstitial ad clicked!");
            }

            @Override
            public void onLoggingImpression(Ad ad) {
                // Ad impression logged callback
                Log.d(TAG, "Interstitial ad impression logged!");
            }
        });

        b1    = (ImageView) findViewById(R.id.button);
        text  = (TextView)findViewById(R.id.textView);
        text2 = (TextView)findViewById(R.id.textView2);
        rootStatus = (TextView) findViewById(R.id.rootStatus);

        red    = (ImageView) findViewById(R.id.imageRed);
        green  = (ImageView) findViewById(R.id.imageGreen);
        bounce = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.anim_bounce);

        //Toast.makeText(this, "Tap the floating #-icon to check root access!", Toast.LENGTH_LONG).show();

        //--------------------------------------
        animate = new TranslateAnimation(0, 0, 11, -11);
        animate.setDuration(1000);
        animate.setFillAfter(true);
        animate.setRepeatMode(2);
        animate.setRepeatCount(Animation.INFINITE);
        b1.startAnimation(animate);             //start Animation
        //--------------------------------------
    }

    public void onCheckRootingButtonClick(View v) {         //Action Listener on button
        RootChecker rc = new RootChecker();
        boolean bRooting1 = rc.execute_su();
        String su = rc.check_su_files();

        if (bRooting1) {
            adView.destroy();
//            AdSettings.addTestDevice("fbc0d94a-629b-488c-8223-0be55d682909");
            adView2.loadAd();
            Toast.makeText(getApplicationContext(), "This Device Is Rooted!", Toast.LENGTH_LONG).show();
            green.setVisibility(View.VISIBLE);
            green.startAnimation(bounce);
            text.setVisibility(View.VISIBLE);
            text2.setVisibility(View.VISIBLE);

            rootStatus.setVisibility(View.VISIBLE);
            rootStatus.setTextColor(Color.parseColor("#00FF00"));
            rootStatus.setText("# ROOTED");
            DisplayAds();       //showAds
        }
        else {
            adView.destroy();
//            AdSettings.addTestDevice("fbc0d94a-629b-488c-8223-0be55d682909");
            adView2.loadAd();
            Toast.makeText(getApplicationContext(), "This Device Is Not Rooted!", Toast.LENGTH_LONG).show();
            red.setVisibility(View.VISIBLE);
            red.startAnimation(bounce);
            text.setVisibility(View.VISIBLE);
            text2.setVisibility(View.VISIBLE);

            rootStatus.setVisibility(View.VISIBLE);
            rootStatus.setTextColor(Color.parseColor("#FF0000"));
            rootStatus.setText("NOT ROOTED!");
            DisplayAds();       //showAds
        }

        if (bRooting1) {
            text.setText("Check execute su : YES");
        }
        else
        {
            text.setText("Check execute su : NO");
        }

        text2.setText("Check existing su file : " + su);
    }

    //========================
    public void DisplayAds(){
//        AdSettings.addTestDevice("fbc0d94a-629b-488c-8223-0be55d682909");
        interstitialAd.loadAd();
    }
    public void DisplayAds2(){
//        AdSettings.addTestDevice("fbc0d94a-629b-488c-8223-0be55d682909");
        adView = new AdView(this, "3295246890507214_3295250397173530", AdSize.BANNER_HEIGHT_50);

        // Add the ad view to your activity layout
        adContainer.addView(adView);

        // Request an ad
        adView.loadAd();
    }

    public void showAlertDialog(){      //Alert dialog
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setMessage("Tap the #-Icon to check Root access properties.");
        builder.setCancelable(false);
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int id) {
                adView.destroy();
                DisplayAds2();
            }
        });
        AlertDialog alert=builder.create();
        alert.show();
    }

}
